package addSystem;

import java.util.concurrent.TimeUnit;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver; 

public class AddSystem {
private static ChromeDriver driver;

	@SuppressWarnings("deprecation")
	@BeforeClass
	public static void openBrowser(){
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\WebDrivers\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	    }
    @Test
	public void test() {
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    	driver.get("http://10.1.40.81:8080/em");
    	driver.manage().window().maximize();
		driver.findElement(By.cssSelector("#user_menu > .dropdown-toggle")).click();
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("loginInput")).sendKeys("admin");
		driver.findElement(By.id("passwordInput")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@value='Log In']")).click();
		driver.findElement(By.cssSelector("a[title='Add System']")).click();
		driver.findElement(By.cssSelector("button[ng-click='controller.createEmpty()']"));
		//if(driver.findElement(By.cssSelector("div.headline-wrapper h2[title='Online Servers']")).isDisplayed()){
		//	System.out.println("Element is Present");
		//}else {
		//	System.out.println("Element is Absent");
		//}
		driver.findElement(By.cssSelector("#user_menu > .dropdown-toggle")).click();
		driver.findElement(By.linkText("Logout")).click();
    		
    	}
    @AfterClass
    public static void closeBrowser(){
        driver.quit();

    }
}