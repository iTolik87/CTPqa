package addSystemImport;

import static org.junit.Assert.*;

import org.junit.Test;

public class SystemImport {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
